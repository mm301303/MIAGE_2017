package logiciel_ascenseur;

enum EEtatOuv {
	OUVERT,
	FERMEE
}