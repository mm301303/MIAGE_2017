package logiciel_ascenseur;

enum EEtatBouton {
	PRESSE,
	RELACHE
}