package logiciel_ascenseur;

public enum EEtatDep {
	ARRETE,
	ENMONTEE,
	ENDESCENTE
}