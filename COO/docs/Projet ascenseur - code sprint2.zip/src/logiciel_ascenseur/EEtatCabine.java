package logiciel_ascenseur;

public enum EEtatCabine {
	ARRETE_FERME,
	ARRETE_OUVERT,
	ENMONTEE_FERME,
	ENDESCENTE_FERME
}