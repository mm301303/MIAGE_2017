package logiciel_ascenseur;

enum ETypeService {
	APPEL,
	SELECTION
}