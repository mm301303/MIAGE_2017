public class Epaisseur {
    public static final char LARGE = 'L';
    public static final char ETROIT = 'E';
    public static final int LARGE_m = 6;
    public static final char ETROIT_m = 3;

}
